-- Migration script to add new fields to existing newsletter_campaign table
-- Run this if you already have the newsletter_campaign table

ALTER TABLE `oc_newsletter_campaign` 
ADD COLUMN IF NOT EXISTS `send_to_type` varchar(50) NOT NULL DEFAULT 'subscribers' AFTER `name`,
ADD COLUMN IF NOT EXISTS `customer_group_ids` text DEFAULT NULL AFTER `send_to_type`,
ADD COLUMN IF NOT EXISTS `custom_emails` text DEFAULT NULL AFTER `customer_group_ids`;

