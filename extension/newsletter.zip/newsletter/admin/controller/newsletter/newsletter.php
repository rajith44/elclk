<?php
namespace Opencart\Admin\Controller\Extension\Newsletter\Newsletter;

class Newsletter extends \Opencart\System\Engine\Controller {
	/**
	 * Check Install
	 *
	 * @return void
	 */
	private function checkInstall(): void {
		// Check if tables exist
		$subscriber_table = $this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "newsletter_subscriber'");
		$campaign_table = $this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "newsletter_campaign'");

		if (!$subscriber_table->num_rows || !$campaign_table->num_rows) {
			$this->install();
		}
	}

	/**
	 * Install
	 *
	 * @return void
	 */
	public function install(): void {
		// Read and execute SQL file
		$sql_file = DIR_EXTENSION . 'newsletter/install.sql';

		if (file_exists($sql_file)) {
			$lines = file($sql_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

			$sql = '';

			foreach ($lines as $line) {
				if ($line && (substr($line, 0, 2) != '--') && (substr($line, 0, 1) != '#')) {
					$sql .= $line;

					if (preg_match('/;\s*$/', $line)) {
						$sql = str_replace("`oc_", "`" . DB_PREFIX, $sql);
						$this->db->query($sql);
						$sql = '';
					}
				}
			}
		}
	}

	/**
	 * Index
	 *
	 * @return void
	 */
	public function index(): void {
		// Register template and language paths
		$this->template->addPath('extension/newsletter', DIR_EXTENSION . 'newsletter/admin/view/template/');
		$this->language->addPath('extension/newsletter', DIR_EXTENSION . 'newsletter/admin/language/');

		// Auto-install database tables if they don't exist
		$this->checkInstall();

		$this->load->language('extension/newsletter/newsletter/newsletter');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->document->addScript('view/javascript/ckeditor/ckeditor.js');
		$this->document->addScript('view/javascript/ckeditor/adapters/jquery.js');

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/newsletter/newsletter/newsletter', 'user_token=' . $this->session->data['user_token'])
		];

		$data['user_token'] = $this->session->data['user_token'];

		// Load model
		$this->load->model('extension/newsletter/newsletter/newsletter');

		// Get campaigns
		$data['campaigns'] = [];

		$results = $this->model_extension_newsletter_newsletter_newsletter->getCampaigns();

		foreach ($results as $result) {
			$data['campaigns'][] = [
				'campaign_id' => $result['campaign_id'],
				'name'        => $result['name'],
				'subject'     => $result['subject'],
				'status'      => $result['status'],
				'total_sent'  => $result['total_sent'],
				'date_created' => date($this->language->get('date_format_short'), strtotime($result['date_created'])),
				'date_sent'   => $result['date_sent'] ? date($this->language->get('date_format_short'), strtotime($result['date_sent'])) : '',
				'edit'        => $this->url->link('extension/newsletter/newsletter/newsletter.form', 'user_token=' . $this->session->data['user_token'] . '&campaign_id=' . $result['campaign_id']),
				'delete'      => $this->url->link('extension/newsletter/newsletter/newsletter.delete', 'user_token=' . $this->session->data['user_token'] . '&campaign_id=' . $result['campaign_id'])
			];
		}

		// Get subscribers
		$data['subscribers'] = [];

		$subscriber_results = $this->model_extension_newsletter_newsletter_newsletter->getSubscribers();

		foreach ($subscriber_results as $subscriber) {
			$data['subscribers'][] = [
				'subscriber_id' => $subscriber['subscriber_id'],
				'email'         => $subscriber['email'],
				'name'          => $subscriber['name'],
				'status'        => $subscriber['status'],
				'date_added'    => date($this->language->get('date_format_short'), strtotime($subscriber['date_added'])),
				'delete'        => $this->url->link('extension/newsletter/newsletter/newsletter.deleteSubscriber', 'user_token=' . $this->session->data['user_token'] . '&subscriber_id=' . $subscriber['subscriber_id'])
			];
		}

		$data['add'] = $this->url->link('extension/newsletter/newsletter/newsletter.form', 'user_token=' . $this->session->data['user_token']);
		$data['subscribers_link'] = $this->url->link('extension/newsletter/newsletter/newsletter.subscribers', 'user_token=' . $this->session->data['user_token']);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('newsletter/newsletter/newsletter', $data));
	}

	/**
	 * Form
	 *
	 * @return void
	 */
	public function form(): void {
		// Register template and language paths
		$this->template->addPath('extension/newsletter', DIR_EXTENSION . 'newsletter/admin/view/template/');
		$this->language->addPath('extension/newsletter', DIR_EXTENSION . 'newsletter/admin/language/');

		$this->load->language('extension/newsletter/newsletter/newsletter');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->document->addScript('view/javascript/ckeditor/ckeditor.js');
		$this->document->addScript('view/javascript/ckeditor/adapters/jquery.js');

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/newsletter/newsletter/newsletter', 'user_token=' . $this->session->data['user_token'])
		];

		$this->load->model('extension/newsletter/newsletter/newsletter');

		$data['campaign'] = [];

		if (isset($this->request->get['campaign_id'])) {
			$campaign_info = $this->model_extension_newsletter_newsletter_newsletter->getCampaign($this->request->get['campaign_id']);

			if ($campaign_info) {
				$data['campaign'] = $campaign_info;
				$data['campaign']['product_ids'] = $campaign_info['product_ids'] ? json_decode($campaign_info['product_ids'], true) : [];
			}
		}

		// Get products with promotions
		$this->load->model('catalog/product');
		$this->load->model('tool/image');

		$data['products'] = [];

		$filter_data = [
			'sort'  => 'pd.name',
			'order' => 'ASC',
			'start' => 0,
			'limit' => 1000
		];

		$products = $this->model_catalog_product->getProducts($filter_data);

		foreach ($products as $product) {
			// Check for special price or discount
			$has_promotion = false;
			$original_price = $product['price'];
			$promotion_price = null;

			// Check for special (special = 1, quantity = 1)
			if (!empty($product['special']) && $product['special'] < $product['price']) {
				$has_promotion = true;
				$promotion_price = $product['special'];
			} elseif (!empty($product['discount']) && $product['discount'] < $product['price']) {
				$has_promotion = true;
				$promotion_price = $product['discount'];
			}

			if ($has_promotion || isset($this->request->get['campaign_id'])) {
				$data['products'][] = [
					'product_id'      => $product['product_id'],
					'name'            => $product['name'],
					'model'           => $product['model'],
					'price'           => $this->currency->format($product['price'], $this->config->get('config_currency')),
					'original_price'   => $original_price,
					'promotion_price' => $promotion_price ? $this->currency->format($promotion_price, $this->config->get('config_currency')) : null,
					'has_promotion'   => $has_promotion,
					'image'           => $this->model_tool_image->resize($product['image'] ?: 'no_image.png', 100, 100)
				];
			}
		}

		$data['user_token'] = $this->session->data['user_token'];
		$data['save'] = $this->url->link('extension/newsletter/newsletter/newsletter.save', 'user_token=' . $this->session->data['user_token']);
		$data['back'] = $this->url->link('extension/newsletter/newsletter/newsletter', 'user_token=' . $this->session->data['user_token']);

		$this->load->model('tool/image');

		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('newsletter/newsletter/newsletter_form', $data));
	}

	/**
	 * Save
	 *
	 * @return void
	 */
	public function save(): void {
		$this->load->language('extension/newsletter/newsletter/newsletter');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/newsletter/newsletter/newsletter')) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		if (!isset($this->request->post['name']) || !$this->request->post['name']) {
			$json['error']['name'] = $this->language->get('error_name');
		}

		if (!isset($this->request->post['subject']) || !$this->request->post['subject']) {
			$json['error']['subject'] = $this->language->get('error_subject');
		}

		if (!isset($this->request->post['message']) || !$this->request->post['message']) {
			$json['error']['message'] = $this->language->get('error_message');
		}

		if (!$json) {
			$this->load->model('extension/newsletter/newsletter/newsletter');

			$product_ids = isset($this->request->post['product_ids']) ? $this->request->post['product_ids'] : [];

			$data = [
				'name'        => $this->request->post['name'],
				'subject'     => $this->request->post['subject'],
				'message'     => $this->request->post['message'],
				'product_ids' => json_encode($product_ids),
				'status'      => isset($this->request->post['status']) ? (int)$this->request->post['status'] : 0
			];

			if (isset($this->request->get['campaign_id'])) {
				$this->model_extension_newsletter_newsletter_newsletter->editCampaign($this->request->get['campaign_id'], $data);
			} else {
				$this->model_extension_newsletter_newsletter_newsletter->addCampaign($data);
			}

			$json['success'] = $this->language->get('text_success');
			$json['redirect'] = $this->url->link('extension/newsletter/newsletter/newsletter', 'user_token=' . $this->session->data['user_token']);
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Send
	 *
	 * @return void
	 */
	public function send(): void {
		$this->load->language('extension/newsletter/newsletter/newsletter');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/newsletter/newsletter/newsletter')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!isset($this->request->get['campaign_id'])) {
			$json['error'] = $this->language->get('error_campaign');
		}

		if (!$json) {
			$this->load->model('extension/newsletter/newsletter/newsletter');

			$campaign = $this->model_extension_newsletter_newsletter_newsletter->getCampaign($this->request->get['campaign_id']);

			if (!$campaign) {
				$json['error'] = $this->language->get('error_campaign');
			} else {
				// Get subscribers
				$subscribers = $this->model_extension_newsletter_newsletter_newsletter->getSubscribers(['status' => 1]);

				if (empty($subscribers)) {
					$json['error'] = $this->language->get('error_no_subscribers');
				} else {
					// Get products
					$product_ids = $campaign['product_ids'] ? json_decode($campaign['product_ids'], true) : [];

					$this->load->model('catalog/product');
					$this->load->model('tool/image');

					$products = [];

					foreach ($product_ids as $product_id) {
						$product_info = $this->model_catalog_product->getProduct($product_id);

						if ($product_info) {
							// Get special/discount price
							$original_price = $product_info['price'];
							$promotion_price = null;
							$has_promotion = false;

							// Check for special price (special = 1, quantity = 1)
							$special_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_discount WHERE product_id = '" . (int)$product_id . "' AND customer_group_id = '" . (int)$this->config->get('config_customer_group_id') . "' AND quantity = '1' AND special = '1' AND ((date_start = '0000-00-00' OR date_start < NOW()) AND (date_end = '0000-00-00' OR date_end > NOW())) ORDER BY priority ASC, price ASC LIMIT 1");

							if ($special_query->num_rows) {
								$discount_row = $special_query->row;
								if ($discount_row['type'] == 'F') {
									$promotion_price = $discount_row['price'];
								} elseif ($discount_row['type'] == 'P') {
									$promotion_price = $original_price - ($original_price * ($discount_row['price'] / 100));
								} elseif ($discount_row['type'] == 'S') {
									$promotion_price = $original_price - $discount_row['price'];
								}
								$has_promotion = true;
							} else {
								// Check for quantity-based discount
								$discount_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_discount WHERE product_id = '" . (int)$product_id . "' AND customer_group_id = '" . (int)$this->config->get('config_customer_group_id') . "' AND quantity = '1' AND special = '0' AND ((date_start = '0000-00-00' OR date_start < NOW()) AND (date_end = '0000-00-00' OR date_end > NOW())) ORDER BY priority ASC, price ASC LIMIT 1");

								if ($discount_query->num_rows) {
									$discount_row = $discount_query->row;
									if ($discount_row['type'] == 'F') {
										$promotion_price = $discount_row['price'];
									} elseif ($discount_row['type'] == 'P') {
										$promotion_price = $original_price - ($original_price * ($discount_row['price'] / 100));
									} elseif ($discount_row['type'] == 'S') {
										$promotion_price = $original_price - $discount_row['price'];
									}
									$has_promotion = true;
								}
							}

							$products[] = [
								'product_id'      => $product_info['product_id'],
								'name'            => $product_info['name'],
								'description'     => strip_tags(html_entity_decode($product_info['description'], ENT_QUOTES, 'UTF-8')),
								'price'           => $this->currency->format($original_price, $this->config->get('config_currency')),
								'promotion_price' => $promotion_price ? $this->currency->format($promotion_price, $this->config->get('config_currency')) : null,
								'has_promotion'   => $has_promotion,
								'image'           => $this->model_tool_image->resize($product_info['image'] ?: 'no_image.png', 300, 300),
								'href'            => $this->url->link('product/product', 'product_id=' . $product_info['product_id'])
							];
						}
					}

					// Send emails
					$total_sent = 0;
					$total_failed = 0;

					foreach ($subscribers as $subscriber) {
						if ($this->config->get('config_mail_engine')) {
							$mail_option = [
								'parameter'     => $this->config->get('config_mail_parameter'),
								'smtp_hostname' => $this->config->get('config_mail_smtp_hostname'),
								'smtp_username' => $this->config->get('config_mail_smtp_username'),
								'smtp_password' => html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8'),
								'smtp_port'     => $this->config->get('config_mail_smtp_port'),
								'smtp_timeout'  => $this->config->get('config_mail_smtp_timeout')
							];

							$mail = new \Opencart\System\Library\Mail($this->config->get('config_mail_engine'), $mail_option);

							$mail->setTo($subscriber['email']);
							$mail->setFrom($this->config->get('config_email'));
							$mail->setSender(html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));
							$mail->setSubject($campaign['subject']);

							$data = [
								'store_name'     => $this->config->get('config_name'),
								'store_url'      => $this->config->get('config_url'),
								'message'        => $campaign['message'],
								'products'       => $products,
								'unsubscribe'    => $this->url->link('extension/newsletter/newsletter/newsletter.unsubscribe', 'email=' . urlencode($subscriber['email']) . '&code=' . md5($subscriber['email'] . $subscriber['subscriber_id']))
							];

							$mail->setHtml($this->load->view('newsletter/newsletter/newsletter_email', $data));

							if ($mail->send()) {
								$total_sent++;
							} else {
								$total_failed++;
							}
						}
					}

					// Update campaign
					$this->model_extension_newsletter_newsletter_newsletter->updateCampaignStats($this->request->get['campaign_id'], $total_sent, $total_failed);

					$json['success'] = sprintf($this->language->get('text_sent'), $total_sent, $total_failed);
				}
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Delete
	 *
	 * @return void
	 */
	public function delete(): void {
		$this->load->language('extension/newsletter/newsletter/newsletter');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/newsletter/newsletter/newsletter')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$json && isset($this->request->get['campaign_id'])) {
			$this->load->model('extension/newsletter/newsletter/newsletter');
			$this->model_extension_newsletter_newsletter_newsletter->deleteCampaign($this->request->get['campaign_id']);
			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Delete Subscriber
	 *
	 * @return void
	 */
	public function deleteSubscriber(): void {
		$this->load->language('extension/newsletter/newsletter/newsletter');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/newsletter/newsletter/newsletter')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$json && isset($this->request->get['subscriber_id'])) {
			$this->load->model('extension/newsletter/newsletter/newsletter');
			$this->model_extension_newsletter_newsletter_newsletter->deleteSubscriber($this->request->get['subscriber_id']);
			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}

