-- Newsletter Subscribers Table
CREATE TABLE IF NOT EXISTS `oc_newsletter_subscriber` (
  `subscriber_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(96) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`subscriber_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Newsletter Campaigns Table
CREATE TABLE IF NOT EXISTS `oc_newsletter_campaign` (
  `campaign_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `send_to_type` varchar(50) NOT NULL DEFAULT 'subscribers',
  `customer_group_ids` text DEFAULT NULL,
  `custom_emails` text DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `product_ids` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `total_sent` int(11) NOT NULL DEFAULT '0',
  `total_failed` int(11) NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `date_sent` datetime DEFAULT NULL,
  PRIMARY KEY (`campaign_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

