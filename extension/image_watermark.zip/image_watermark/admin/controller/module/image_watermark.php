<?php
namespace Opencart\Admin\Controller\Extension\ImageWatermark\Module;
/**
 * Class ImageWatermark
 *
 * @package Opencart\Admin\Controller\Extension\ImageWatermark\Module
 */
class ImageWatermark extends \Opencart\System\Engine\Controller {
	private string $event_code = 'image_watermark';

	/**
	 * @return void
	 */
	public function index(): void {
		$this->load->language('extension/image_watermark/module/image_watermark');

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/image_watermark/module/image_watermark', 'user_token=' . $this->session->data['user_token'])
		];

		$data['save'] = $this->url->link('extension/image_watermark/module/image_watermark.save', 'user_token=' . $this->session->data['user_token']);
		$data['clear_cache'] = $this->url->link('extension/image_watermark/module/image_watermark.clearCache', 'user_token=' . $this->session->data['user_token']);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

		$defaults = [
			'module_image_watermark_status'     => 0,
			'module_image_watermark_image'      => 'catalog/watermark.png',
			'module_image_watermark_opacity'    => 40,
			'module_image_watermark_position'   => 'bottom_right',
			'module_image_watermark_scale'      => 20,
			'module_image_watermark_padding'    => 10,
			'module_image_watermark_min_width'  => 100,
			'module_image_watermark_min_height' => 100,
			'module_image_watermark_admin'      => 1,
		];

		foreach ($defaults as $key => $default) {
			$short = substr($key, strlen('module_image_watermark_'));

			if ($this->config->has($key)) {
				$data[$short] = $this->config->get($key);
			} else {
				$data[$short] = $default;
			}
		}

		$data['positions'] = [
			'bottom_right' => $this->language->get('text_bottom_right'),
			'bottom_left'  => $this->language->get('text_bottom_left'),
			'top_right'    => $this->language->get('text_top_right'),
			'top_left'     => $this->language->get('text_top_left'),
			'center'       => $this->language->get('text_center'),
		];

		$data['help_image'] = $this->language->get('help_image');
		$data['help_scale'] = $this->language->get('help_scale');
		$data['help_clear_cache'] = $this->language->get('help_clear_cache');
		$data['user_token'] = $this->session->data['user_token'];

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/image_watermark/module/image_watermark', $data));
	}

	/**
	 * @return void
	 */
	public function save(): void {
		$this->load->language('extension/image_watermark/module/image_watermark');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/image_watermark/module/image_watermark')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$json) {
			$this->load->model('setting/setting');

			$post = $this->request->post;

			$this->model_setting_setting->editSetting('module_image_watermark', [
				'module_image_watermark_status'      => isset($post['status']) ? (int)$post['status'] : 0,
				'module_image_watermark_image'       => trim((string)($post['image'] ?? '')),
				'module_image_watermark_opacity'     => max(1, min(100, (int)($post['opacity'] ?? 40))),
				'module_image_watermark_position'    => (string)($post['position'] ?? 'bottom_right'),
				'module_image_watermark_scale'       => max(5, min(80, (int)($post['scale'] ?? 20))),
				'module_image_watermark_padding'     => max(0, (int)($post['padding'] ?? 10)),
				'module_image_watermark_min_width'   => max(1, (int)($post['min_width'] ?? 100)),
				'module_image_watermark_min_height'  => max(1, (int)($post['min_height'] ?? 100)),
				'module_image_watermark_admin'       => isset($post['admin']) ? (int)$post['admin'] : 0,
			]);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * @return void
	 */
	public function clearCache(): void {
		$this->load->language('extension/image_watermark/module/image_watermark');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/image_watermark/module/image_watermark')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$json) {
			$this->load->model('extension/image_watermark/module/image_watermark');

			$count = $this->model_extension_image_watermark_module_image_watermark->clearImageCache();

			$json['success'] = sprintf($this->language->get('text_cache_cleared'), $count);
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * @return void
	 */
	public function install(): void {
		$this->load->model('user/user_group');

		$route = 'extension/image_watermark/module/image_watermark';

		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $route);
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $route);

		$this->load->model('setting/event');

		$this->model_setting_event->deleteEventByCode($this->event_code);

		$events = [
			[
				'description' => 'Image watermark on catalog resize',
				'trigger'     => 'catalog/model/tool/image.resize/after',
				'action'      => 'extension/image_watermark/event/image.catalogAfter'
			],
			[
				'description' => 'Image watermark on admin resize',
				'trigger'     => 'admin/model/tool/image.resize/after',
				'action'      => 'extension/image_watermark/event/image.after'
			],
		];

		foreach ($events as $event) {
			$this->model_setting_event->addEvent([
				'code'        => $this->event_code,
				'description' => $event['description'],
				'trigger'     => $event['trigger'],
				'action'      => $event['action'],
				'status'      => 1,
				'sort_order'  => 0
			]);
		}

		$this->load->model('setting/startup');

		$this->model_setting_startup->deleteStartupByCode($this->event_code);

		$this->model_setting_startup->addStartup([
			'code'       => $this->event_code,
			'description'=> 'Image watermark Journal3 wrapper',
			'action'     => 'catalog/extension/image_watermark/startup/image_watermark',
			'status'     => 1,
			'sort_order' => 20
		]);
	}

	/**
	 * @return void
	 */
	public function uninstall(): void {
		if (!$this->user->hasPermission('modify', 'extension/image_watermark/module/image_watermark')) {
			return;
		}

		$this->load->model('setting/event');
		$this->load->model('setting/startup');

		$this->model_setting_event->deleteEventByCode($this->event_code);
		$this->model_setting_startup->deleteStartupByCode($this->event_code);
	}
}
