<?php
namespace Opencart\Admin\Controller\Extension\ImageWatermark\Event;
/**
 * Class Image
 *
 * @package Opencart\Admin\Controller\Extension\ImageWatermark\Event
 */
class Image extends \Opencart\System\Engine\Controller {
	/**
	 * @return \Opencart\System\Library\Extension\ImageWatermark\Watermark
	 */
	private function getWatermark(): \Opencart\System\Library\Extension\ImageWatermark\Watermark {
		static $watermark = null;

		if ($watermark === null) {
			if (!class_exists('\Opencart\System\Library\Extension\ImageWatermark\Watermark', false)) {
				$this->autoloader->register(
					'Opencart\System\Library\Extension\ImageWatermark',
					DIR_EXTENSION . 'image_watermark/system/library/'
				);
			}

			$watermark = new \Opencart\System\Library\Extension\ImageWatermark\Watermark($this->registry);
		}

		return $watermark;
	}

	/**
	 * @param string            $route
	 * @param array<int, mixed> $args
	 * @param mixed             $output
	 *
	 * @return void
	 */
	public function after(string &$route, array &$args, mixed &$output): void {
		if (!$this->config->get('module_image_watermark_status') || !$this->config->get('module_image_watermark_admin')) {
			return;
		}

		$filename = (string)($args[0] ?? '');

		if ($filename === '') {
			return;
		}

		$model = $this->getWatermark();

		if (is_string($output) && $output !== '') {
			$model->applyFromUrl($output, $filename, (int)($args[1] ?? 0), (int)($args[2] ?? 0), (string)($args[3] ?? ''));

			return;
		}

		$width = (int)($args[1] ?? 0);
		$height = (int)($args[2] ?? 0);

		if ($width < 1 || $height < 1) {
			return;
		}

		$model->applyFromResize($filename, $width, $height, (string)($args[3] ?? ''));
	}
}
