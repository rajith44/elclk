<?php
namespace Opencart\Admin\Model\Extension\ImageWatermark\Module;
/**
 * Class ImageWatermark
 *
 * @package Opencart\Admin\Model\Extension\ImageWatermark\Module
 */
class ImageWatermark extends \Opencart\System\Engine\Model {
	/**
	 * @return int
	 */
	public function clearImageCache(): int {
		return $this->deleteCachedFiles(DIR_IMAGE . 'cache/');
	}

	/**
	 * @param string $directory
	 *
	 * @return int
	 */
	private function deleteCachedFiles(string $directory): int {
		$count = 0;

		if (!is_dir($directory)) {
			return 0;
		}

		foreach (array_diff(scandir($directory), ['.', '..']) as $item) {
			$path = $directory . $item;

			if (is_dir($path)) {
				$count += $this->deleteCachedFiles($path . '/');
				continue;
			}

			if (@unlink($path)) {
				$count++;
			}
		}

		return $count;
	}
}
