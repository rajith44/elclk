<?php
// Heading
$_['heading_title']          = 'Image Watermark';

// Text
$_['text_extension']         = 'Extensions';
$_['text_success']           = 'Success: You have modified Image Watermark settings!';
$_['text_edit']              = 'Edit Image Watermark';
$_['text_bottom_right']      = 'Bottom Right';
$_['text_bottom_left']       = 'Bottom Left';
$_['text_top_right']         = 'Top Right';
$_['text_top_left']          = 'Top Left';
$_['text_center']            = 'Center';
$_['text_cache_cleared']     = 'Success: %s cached image files were deleted. Images will rebuild with watermarks on next view.';

// Entry
$_['entry_status']           = 'Status';
$_['entry_image']            = 'Watermark Image';
$_['entry_opacity']          = 'Opacity';
$_['entry_position']         = 'Position';
$_['entry_scale']            = 'Scale (% of image width)';
$_['entry_padding']          = 'Padding (px)';
$_['entry_min_width']        = 'Minimum Image Width';
$_['entry_min_height']       = 'Minimum Image Height';
$_['entry_admin']            = 'Apply in Admin Previews';

// Help
$_['help_image']             = 'Upload a transparent PNG to the image folder (e.g. catalog/watermark.png) and enter the path here.';
$_['help_scale']             = 'Watermark width as a percentage of the generated image width.';
$_['help_clear_cache']       = 'Delete generated thumbnails in image/cache/ so they rebuild with the watermark. Original uploads are not changed.';

// Button
$_['button_save']            = 'Save';
$_['button_back']            = 'Back';
$_['button_clear_cache']     = 'Clear Image Cache';

// Error
$_['error_permission']       = 'Warning: You do not have permission to modify Image Watermark!';
