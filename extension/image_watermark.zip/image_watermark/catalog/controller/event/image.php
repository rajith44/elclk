<?php
namespace Opencart\Catalog\Controller\Extension\ImageWatermark\Event;
/**
 * Class Image
 *
 * @package Opencart\Catalog\Controller\Extension\ImageWatermark\Event
 */
class Image extends \Opencart\System\Engine\Controller {
	/**
	 * @param string            $route
	 * @param array<int, mixed> $args
	 * @param mixed             $output
	 *
	 * @return void
	 */
	public function catalogAfter(string &$route, array &$args, mixed &$output): void {
		if (!$this->config->get('module_image_watermark_status')) {
			return;
		}

		$filename = (string)($args[0] ?? '');

		if ($filename === '') {
			return;
		}

		$this->load->model('extension/image_watermark/module/watermark');

		$model = $this->model_extension_image_watermark_module_watermark;

		if (is_string($output) && $output !== '') {
			$model->applyFromUrl($output, $filename, (int)($args[1] ?? 0), (int)($args[2] ?? 0), (string)($args[3] ?? ''));

			return;
		}

		$width = (int)($args[1] ?? 0);
		$height = (int)($args[2] ?? 0);

		if ($width < 1 || $height < 1) {
			return;
		}

		$model->applyFromResize($filename, $width, $height, (string)($args[3] ?? ''));
	}
}
