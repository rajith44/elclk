<?php
namespace Opencart\Catalog\Controller\Extension\ImageWatermark\Startup;
/**
 * Class ImageWatermark
 *
 * @package Opencart\Catalog\Controller\Extension\ImageWatermark\Startup
 */
class ImageWatermark extends \Opencart\System\Engine\Controller {
	/**
	 * @return void
	 */
	public function index(): void {
		if (!$this->config->get('module_image_watermark_status')) {
			return;
		}

		if (!defined('JOURNAL3_ACTIVE') || !$this->registry->has('journal3_image')) {
			return;
		}

		require_once DIR_EXTENSION . 'image_watermark/system/library/journal3_image.php';

		$this->registry->set('journal3_image', new \Opencart\Extension\ImageWatermark\Library\Journal3Image($this->registry));
	}
}
