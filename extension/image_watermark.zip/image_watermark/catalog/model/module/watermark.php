<?php
namespace Opencart\Catalog\Model\Extension\ImageWatermark\Module;
/**
 * Class Watermark
 *
 * @package Opencart\Catalog\Model\Extension\ImageWatermark\Module
 */
class Watermark extends \Opencart\System\Library\Extension\ImageWatermark\Watermark {
}
