<?php
namespace Opencart\System\Library\Extension\ImageWatermark;
/**
 * Shared watermark logic for catalog and admin.
 */
class Watermark extends \Opencart\System\Engine\Model {
	/**
	 * @param string $filename
	 * @param int    $width
	 * @param int    $height
	 * @param string $resize_type
	 *
	 * @return void
	 */
	public function applyFromResize(string $filename, int $width, int $height, string $resize_type = ''): void {
		if (!$this->isEnabled() || $filename === '' || $width < 1 || $height < 1) {
			return;
		}

		if (!$this->shouldWatermarkSource($filename)) {
			return;
		}

		$extension = pathinfo($filename, PATHINFO_EXTENSION);
		$cache_file = $this->buildCachePath($filename, $width, $height, $resize_type, $extension);

		$this->applyToFile($cache_file);

		$webp_file = $cache_file . '.webp';

		if (is_file(DIR_IMAGE . $webp_file)) {
			$this->applyToFile($webp_file);
		}
	}

	/**
	 * @param string $url
	 * @param string $source_filename
	 * @param int    $width
	 * @param int    $height
	 * @param string $resize_type
	 *
	 * @return void
	 */
	public function applyFromUrl(string $url, string $source_filename = '', int $width = 0, int $height = 0, string $resize_type = ''): void {
		if (!$this->isEnabled() || $url === '') {
			return;
		}

		$relative = $this->urlToRelativePath($url);

		if ($relative !== '') {
			if (!$this->shouldWatermarkSource($source_filename ?: $relative)) {
				return;
			}

			$this->applyToFile($relative);

			return;
		}

		if ($source_filename !== '' && $width > 0 && $height > 0) {
			$this->applyFromResize($source_filename, $width, $height, $resize_type);
		}
	}

	/**
	 * @param string $relative_path
	 *
	 * @return bool
	 */
	public function applyToFile(string $relative_path): bool {
		if (!$this->isEnabled()) {
			return false;
		}

		$relative_path = str_replace('\\', '/', $relative_path);

		if ($relative_path === '' || strpos($relative_path, 'cache/') !== 0) {
			return false;
		}

		$target = DIR_IMAGE . $relative_path;

		if (!is_file($target)) {
			return false;
		}

		$watermark_path = $this->getWatermarkPath();

		if ($watermark_path === '') {
			return false;
		}

		[$target_width, $target_height, $target_type] = @getimagesize($target);

		if (!$target_width || !$target_height) {
			return false;
		}

		$min_width = (int)$this->config->get('module_image_watermark_min_width');
		$min_height = (int)$this->config->get('module_image_watermark_min_height');

		if ($target_width < max(1, $min_width) || $target_height < max(1, $min_height)) {
			return false;
		}

		$target_image = $this->createImageResource($target, $target_type);

		if (!$target_image) {
			return false;
		}

		$watermark_image = $this->createImageResource($watermark_path, (int)@exif_imagetype($watermark_path));

		if (!$watermark_image) {
			imagedestroy($target_image);

			return false;
		}

		$this->preserveAlpha($watermark_image);

		$scale = max(5, min(80, (int)$this->config->get('module_image_watermark_scale')));
		$wm_target_width = (int)round($target_width * ($scale / 100));
		$wm_orig_width = imagesx($watermark_image);
		$wm_orig_height = imagesy($watermark_image);
		$wm_target_height = (int)round($wm_orig_height * ($wm_target_width / max(1, $wm_orig_width)));

		if ($wm_target_width < 1 || $wm_target_height < 1) {
			imagedestroy($target_image);
			imagedestroy($watermark_image);

			return false;
		}

		$scaled = $this->scaleWatermarkImage($watermark_image, $wm_target_width, $wm_target_height);

		imagedestroy($watermark_image);

		if (!$scaled) {
			imagedestroy($target_image);

			return false;
		}

		[$dest_x, $dest_y] = $this->getPosition(
			(string)$this->config->get('module_image_watermark_position'),
			$target_width,
			$target_height,
			$wm_target_width,
			$wm_target_height
		);

		$opacity = max(1, min(100, (int)$this->config->get('module_image_watermark_opacity')));
		$this->overlayWatermark($target_image, $scaled, $dest_x, $dest_y, $opacity);

		imagedestroy($scaled);

		$result = $this->saveImageResource($target_image, $target, $target_type);
		imagedestroy($target_image);

		return $result;
	}

	/**
	 * @return bool
	 */
	public function isEnabled(): bool {
		return (bool)$this->config->get('module_image_watermark_status') && $this->getWatermarkPath() !== '';
	}

	/**
	 * @return string
	 */
	public function getWatermarkPath(): string {
		$file = trim((string)$this->config->get('module_image_watermark_image'));

		if ($file === '') {
			return '';
		}

		$path = DIR_IMAGE . $file;

		return is_file($path) ? $path : '';
	}

	/**
	 * @param string $filename
	 *
	 * @return bool
	 */
	public function shouldWatermarkSource(string $filename): bool {
		$filename = str_replace('\\', '/', trim($filename));

		if ($filename === '') {
			return false;
		}

		$skip = [
			'cache/',
			'watermark',
			'placeholder',
			'no_image',
			'no-image',
			'payment/',
			'flags/',
		];

		foreach ($skip as $needle) {
			if (stripos($filename, $needle) !== false) {
				return false;
			}
		}

		return true;
	}

	/**
	 * @param string $filename
	 * @param int    $width
	 * @param int    $height
	 * @param string $resize_type
	 * @param string $extension
	 *
	 * @return string
	 */
	public function buildCachePath(string $filename, int $width, int $height, string $resize_type, string $extension): string {
		$dot = oc_strrpos($filename, '.');

		if ($dot === false) {
			return 'cache/' . $filename . '-' . $width . 'x' . $height . $resize_type . '.' . $extension;
		}

		return 'cache/' . oc_substr($filename, 0, $dot) . '-' . $width . 'x' . $height . $resize_type . '.' . $extension;
	}

	/**
	 * @param string $url
	 *
	 * @return string
	 */
	private function urlToRelativePath(string $url): string {
		$path = parse_url($url, PHP_URL_PATH);

		if (!$path) {
			return '';
		}

		$marker = '/image/';

		if (($pos = strpos($path, $marker)) === false) {
			return '';
		}

		return ltrim(rawurldecode(substr($path, $pos + strlen($marker))), '/');
	}

	/**
	 * @param string $position
	 * @param int    $target_width
	 * @param int    $target_height
	 * @param int    $wm_width
	 * @param int    $wm_height
	 *
	 * @return array{0:int,1:int}
	 */
	private function getPosition(string $position, int $target_width, int $target_height, int $wm_width, int $wm_height): array {
		$padding = max(0, (int)$this->config->get('module_image_watermark_padding'));

		return match ($position) {
			'top_left'     => [$padding, $padding],
			'top_right'    => [$target_width - $wm_width - $padding, $padding],
			'center'       => [(int)(($target_width - $wm_width) / 2), (int)(($target_height - $wm_height) / 2)],
			'bottom_left'  => [$padding, $target_height - $wm_height - $padding],
			'bottom_right' => [$target_width - $wm_width - $padding, $target_height - $wm_height - $padding],
			default        => [$target_width - $wm_width - $padding, $target_height - $wm_height - $padding],
		};
	}

	/**
	 * @param \GdImage|resource $image
	 *
	 * @return void
	 */
	private function preserveAlpha($image): void {
		imagealphablending($image, false);
		imagesavealpha($image, true);
	}

	/**
	 * @param \GdImage|resource $source
	 * @param int               $width
	 * @param int               $height
	 *
	 * @return \GdImage|resource|null
	 */
	private function scaleWatermarkImage($source, int $width, int $height) {
		$scaled = imagecreatetruecolor($width, $height);

		if (!$scaled) {
			return null;
		}

		$this->preserveAlpha($scaled);

		$transparent = imagecolorallocatealpha($scaled, 0, 0, 0, 127);
		imagefilledrectangle($scaled, 0, 0, $width, $height, $transparent);

		$this->preserveAlpha($source);
		imagealphablending($scaled, true);
		imagesavealpha($scaled, true);
		imagecopyresampled($scaled, $source, 0, 0, 0, 0, $width, $height, imagesx($source), imagesy($source));
		$this->preserveAlpha($scaled);

		return $scaled;
	}

	/**
	 * Overlay a transparent PNG watermark while respecting per-pixel alpha.
	 *
	 * @param \GdImage|resource $target
	 * @param \GdImage|resource $watermark
	 * @param int               $dest_x
	 * @param int               $dest_y
	 * @param int               $opacity
	 *
	 * @return void
	 */
	private function overlayWatermark($target, $watermark, int $dest_x, int $dest_y, int $opacity): void {
		$wm_width = imagesx($watermark);
		$wm_height = imagesy($watermark);
		$opacity = max(1, min(100, $opacity)) / 100;

		imagealphablending($target, true);

		for ($x = 0; $x < $wm_width; $x++) {
			for ($y = 0; $y < $wm_height; $y++) {
				$rgba = imagecolorat($watermark, $x, $y);
				$alpha = ($rgba >> 24) & 0x7F;

				if ($alpha >= 127) {
					continue;
				}

				$src_opacity = (127 - $alpha) / 127 * $opacity;

				if ($src_opacity <= 0) {
					continue;
				}

				$src_r = ($rgba >> 16) & 0xFF;
				$src_g = ($rgba >> 8) & 0xFF;
				$src_b = $rgba & 0xFF;

				$target_x = $dest_x + $x;
				$target_y = $dest_y + $y;

				if ($target_x < 0 || $target_y < 0 || $target_x >= imagesx($target) || $target_y >= imagesy($target)) {
					continue;
				}

				$dst_rgba = imagecolorat($target, $target_x, $target_y);
				$dst_r = ($dst_rgba >> 16) & 0xFF;
				$dst_g = ($dst_rgba >> 8) & 0xFF;
				$dst_b = $dst_rgba & 0xFF;

				$new_r = (int)round($dst_r * (1 - $src_opacity) + $src_r * $src_opacity);
				$new_g = (int)round($dst_g * (1 - $src_opacity) + $src_g * $src_opacity);
				$new_b = (int)round($dst_b * (1 - $src_opacity) + $src_b * $src_opacity);

				$color = imagecolorallocate($target, $new_r, $new_g, $new_b);
				imagesetpixel($target, $target_x, $target_y, $color);
			}
		}
	}

	/**
	 * @param string $file
	 * @param int    $type
	 *
	 * @return \GdImage|resource|null
	 */
	private function createImageResource(string $file, int $type) {
		$image = match ($type) {
			IMAGETYPE_PNG  => @imagecreatefrompng($file),
			IMAGETYPE_JPEG => @imagecreatefromjpeg($file),
			IMAGETYPE_GIF  => @imagecreatefromgif($file),
			IMAGETYPE_WEBP => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($file) : null,
			default        => null,
		};

		if ($image && in_array($type, [IMAGETYPE_PNG, IMAGETYPE_GIF, IMAGETYPE_WEBP], true)) {
			$this->preserveAlpha($image);
		}

		return $image;
	}

	/**
	 * @param \GdImage|resource $image
	 * @param string            $file
	 * @param int               $type
	 *
	 * @return bool
	 */
	private function saveImageResource($image, string $file, int $type): bool {
		return match ($type) {
			IMAGETYPE_PNG  => imagepng($image, $file, 9),
			IMAGETYPE_JPEG => imagejpeg($image, $file, 90),
			IMAGETYPE_GIF  => imagegif($image, $file),
			IMAGETYPE_WEBP => function_exists('imagewebp') ? imagewebp($image, $file, 90) : false,
			default        => false,
		};
	}
}
