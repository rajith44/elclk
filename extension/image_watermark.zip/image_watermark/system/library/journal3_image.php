<?php
namespace Opencart\Extension\ImageWatermark\Library;

/**
 * Journal3 image wrapper — applies watermark after resize.
 */
class Journal3Image extends \Journal3\Image {
	/**
	 * @param mixed       $filename
	 * @param mixed       $width
	 * @param mixed       $height
	 * @param string      $resize_type
	 * @param bool        $convert_cwebp
	 *
	 * @return mixed
	 */
	public function resize($filename, $width = null, $height = null, $resize_type = '', $convert_cwebp = true) {
		$result = parent::resize($filename, $width, $height, $resize_type, $convert_cwebp);

		if (!$this->config->get('module_image_watermark_status')) {
			return $result;
		}

		$source = is_array($filename) ? '' : (string)$filename;

		if ($source === '' || !is_string($result)) {
			return $result;
		}

		$this->load->model('extension/image_watermark/module/watermark');

		$this->model_extension_image_watermark_module_watermark->applyFromUrl(
			$result,
			$source,
			(int)$this->width,
			(int)$this->height,
			(string)$resize_type
		);

		return $result;
	}
}
