<?php
/**
 * One-time installer for Image Watermark extension.
 * Run: C:\xampp\php\php.exe extension/image_watermark/install.php
 */
require dirname(__DIR__, 2) . '/config.php';

$db = new mysqli(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE, DB_PORT);

if ($db->connect_error) {
	die('DB connection failed: ' . $db->connect_error . PHP_EOL);
}

$prefix = DB_PREFIX;

$db->query("INSERT IGNORE INTO `{$prefix}extension` SET `extension` = 'image_watermark', `type` = 'module', `code` = 'image_watermark'");

$settings = [
	'module_image_watermark_status'      => '0',
	'module_image_watermark_image'       => 'catalog/watermark.png',
	'module_image_watermark_opacity'     => '40',
	'module_image_watermark_position'    => 'bottom_right',
	'module_image_watermark_scale'       => '20',
	'module_image_watermark_padding'     => '10',
	'module_image_watermark_min_width'   => '100',
	'module_image_watermark_min_height'  => '100',
	'module_image_watermark_admin'       => '1',
];

foreach ($settings as $key => $value) {
	$db->query("DELETE FROM `{$prefix}setting` WHERE `store_id` = 0 AND `code` = 'module_image_watermark' AND `key` = '" . $db->real_escape_string($key) . "'");
	$db->query("INSERT INTO `{$prefix}setting` SET `store_id` = 0, `code` = 'module_image_watermark', `key` = '" . $db->real_escape_string($key) . "', `value` = '" . $db->real_escape_string($value) . "', `serialized` = 0");
}

$event_code = 'image_watermark';

$db->query("DELETE FROM `{$prefix}event` WHERE `code` = '" . $db->real_escape_string($event_code) . "'");

$events = [
	[
		'description' => 'Image watermark on catalog resize',
		'trigger'     => 'catalog/model/tool/image.resize/after',
		'action'      => 'extension/image_watermark/event/image.catalogAfter'
	],
	[
		'description' => 'Image watermark on admin resize',
		'trigger'     => 'admin/model/tool/image.resize/after',
		'action'      => 'extension/image_watermark/event/image.after'
	],
];

foreach ($events as $event) {
	$db->query("INSERT INTO `{$prefix}event` SET
		`code` = '" . $db->real_escape_string($event_code) . "',
		`description` = '" . $db->real_escape_string($event['description']) . "',
		`trigger` = '" . $db->real_escape_string($event['trigger']) . "',
		`action` = '" . $db->real_escape_string($event['action']) . "',
		`status` = 1,
		`sort_order` = 0");
}

$db->query("DELETE FROM `{$prefix}startup` WHERE `code` = '" . $db->real_escape_string($event_code) . "'");
$db->query("INSERT INTO `{$prefix}startup` SET
	`code` = '" . $db->real_escape_string($event_code) . "',
	`description` = 'Image watermark Journal3 wrapper',
	`action` = 'catalog/extension/image_watermark/startup/image_watermark',
	`status` = 1,
	`sort_order` = 20");

$permission_route = 'extension/image_watermark/module/image_watermark';
$groups = $db->query("SELECT user_group_id, permission FROM `{$prefix}user_group`");

while ($group = $groups->fetch_assoc()) {
	$data = $group['permission'] ? json_decode($group['permission'], true) : [];

	if (!is_array($data)) {
		$data = [];
	}

	foreach (['access', 'modify'] as $type) {
		if (!isset($data[$type]) || !is_array($data[$type])) {
			$data[$type] = [];
		}

		if (!in_array($permission_route, $data[$type], true)) {
			$data[$type][] = $permission_route;
		}
	}

	$db->query("UPDATE `{$prefix}user_group` SET `permission` = '" . $db->real_escape_string(json_encode($data)) . "' WHERE `user_group_id` = '" . (int)$group['user_group_id'] . "'");
}

echo "Image Watermark installed successfully.\n";
echo "1. Upload a transparent PNG to image/catalog/watermark.png\n";
echo "2. Enable at Admin > Extensions > Modules > Image Watermark\n";
echo "3. Click Clear Image Cache to rebuild existing thumbnails\n";
